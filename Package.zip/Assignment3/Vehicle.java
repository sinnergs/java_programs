package com.automobile;

public abstract class Vehicle{
    abstract public void getModelName();
    abstract public void  getRegistrationNumber();
    abstract public void getOwnerName();

}