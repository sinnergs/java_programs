package testpackage;
import testpackage.Foundation.*;
public class Assignment1{
    public static void main(String args[]){
        Foundation f = new Foundation();
        System.out.println(f.var4);
    }
}