class Fruit{
    protected String name,taste;
    protected int size;

    void eat(){
        System.out.print("name : "+name);
        System.out.println("taste : "+ taste);
    }

}
class Apple extends Fruit{
    void eat(){
        System.out.println("Apple is sweet");
    }
}
class Orange extends Fruit{
    void eat(){
        System.out.println("Orange is sour");
    }
}
public class Assignment1{
    public static void main(String args[]){
        Apple a = new Apple();
        Orange o = new Orange();
        a.eat();
        o.eat();
    }
}