import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
class EmployeeTest {
	@Before
		void before() {
			System.out.println("before");
		}
		
		@After
		void after() {
			System.out.println("after");
		}
	
	@Test
	void testFindName() {
		Employee e = new Employee();
		ArrayList<String> list = new ArrayList<>();
		{
			list.add("Bob");
			list.add("Alice");
			list.add("John");
		}
		System.out.println(list);
		assertEquals("FOUND", e.findName(list, "Alice"));
		System.out.println("test");
	}
}
