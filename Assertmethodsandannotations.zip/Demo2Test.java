import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Demo2Test {

	@Test
	public void palindromeCheck() {
		Demo2 d = new Demo2();
		assertTrue(d.palindromeCheck("Nitin"));
		assertTrue(d.palindromeCheck("1221"));
	}

}
