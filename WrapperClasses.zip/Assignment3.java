import java.util.*;
public class Assignment3{
    public static void main(String args[]){
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter an integer num btw 1-255");
            int a = sc.nextInt();
            if (a>=1 && a<=255){
                String b = Integer.toBinaryString(a);
                int bc = Integer.parseInt(b);
                String s = String.format("%08d",bc);
                System.out.println(s);
            }
            else{
                System.out.println("Enter an integer num btw 1-255");
            }

    }
}