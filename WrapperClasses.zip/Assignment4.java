class Employee implements Cloneable{
    String name;
    int age;
    Employee(String name,int age){
        this.name=name;
        this.age=age;
    }
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
    public void setName(String name){
        this.name=name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }
}
public class Assignment4{
    public static void main(String args[]){
        try{
            Employee e = new Employee("Gurpreet",22);
            Employee e2 = (Employee)e.clone();
            System.out.println("before changeing value of original object ");
            System.out.println(e.getName());
            System.out.println(e.getAge());
            System.out.println(e2.getName());
            System.out.println(e2.getAge());
            e.setAge(21);
            e.setName("wipro");
            System.out.println("after changeing value of original object ");
            System.out.println(e.getName());
            System.out.println(e.getAge());
            System.out.println(e2.getName());
            System.out.println(e2.getAge());
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}