import java.util.*;
public class Calculator{
    public static double powerInt(int num1,int num2){
        return Math.pow(num1,num2);
    }
    public static double powerDouble(double num1,int num2){
        return Math.pow(num1,num2);
    }
    public static void main(String[] args){
        Calculator c = new Calculator();
        double powint = c.powerInt(2,5);
        double powdoub = c.powerDouble(2.4,5);
        System.out.println(powint);
        System.out.println(powdoub);
    }
}