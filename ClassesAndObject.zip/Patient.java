public class Patient{
    double h,w;
    String n;
    Patient(String name,double height,double weight){
        n = name;
        h=height;
        w=weight;
    }
    public double computeBMI(){
        return w+(h*h);
    }

    public static void main(String[] args){
        Patient p = new Patient("gurpreet",1.75,80);
        System.out.println("BMI of "+p.n+" is "+p.computeBMI());
        Patient pp = new Patient("yash",1.55,60);
        System.out.println("BMI of "+pp.n+" is "+pp.computeBMI());
    }
}