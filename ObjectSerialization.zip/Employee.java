import java.io.*;
import java.util.Date;

public class Employee implements Serializable{
    public String name;
    public Date dateOfBirth;
    public String department;
    public String designation;
    public double salary;

    Employee(String name,Date dateOfBirth,String department,String designation,double salary){
        this.name=name;
        this.dateOfBirth=dateOfBirth;
        this.department=department;
        this.designation=designation;
        this.salary=salary;
    }

    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public String getDepartment() {
        return department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
