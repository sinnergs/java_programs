import java.io.*;
import java.util.Date;

public class Assignment1{
    public static void main(String args[]){
        Employee e = new Employee("gurpreet",new Date(),"cs","se",150000000.0);
        try {
            FileOutputStream fileOut = new FileOutputStream("employee.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(e);
            out.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in employee.ser");
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
}