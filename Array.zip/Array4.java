public class Array4{
    public static void main(String args[]){
        int[] arr = {65,122,97,70};
        for(int i:arr){
            System.out.print((char) i+" ");
        }
    }
}