package live;
import music.string.Veena;
import music.wind.Saxophone;
import music.Playable;
public class Test{
    public static void main(String args[]){
        Veena v = new Veena();
        v.play();
        Saxophone s = new Saxophone();
        s.play();
        Playable p=v;
        p.play();
        Playable ss=s;
        ss.play();

    }
}