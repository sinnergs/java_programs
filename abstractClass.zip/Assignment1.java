abstract class GeneralBank{
    abstract  String getSavingsInterestRate();
    abstract  String getFixedDepositInterestRate();
}

class ICICIBank extends GeneralBank
{
    @java.lang.Override
    String getSavingsInterestRate() {
        return "Saving - 4%";
    }

    @java.lang.Override
    String getFixedDepositInterestRate() {
        return "Fixed - 8.5%";
    }
}

class KotMBank extends GeneralBank
{
    @java.lang.Override
    String getSavingsInterestRate() {
        return "Saving - 6%";
    }

    @java.lang.Override
    String getFixedDepositInterestRate() {
        return "Fixed - 9%";
    }
}

class Assignment1{
    public static void main(String args[]){
        ICICIBank i=new ICICIBank();
        System.out.println(i.getFixedDepositInterestRate()+i.getSavingsInterestRate());
        KotMBank k=new KotMBank();
        System.out.println(k.getFixedDepositInterestRate()+k.getSavingsInterestRate());
        GeneralBank g=new KotMBank();
        System.out.println(g.getFixedDepositInterestRate()+g.getSavingsInterestRate());
        GeneralBank g2=new ICICIBank();
        System.out.println(g2.getFixedDepositInterestRate()+g2.getSavingsInterestRate());
    }
}