public class Employee extends Dearness{
       public int empno;
       public String empname,joindate,department;
        public char designation_code;
        public double basic,hr,it;
        Employee(String designation,double da,int empno,String empname,String joindate,String department,char designation_code,double basic,double hr,double it){
            super(designation,da);
            this.empname=empname;
            this.empno=empno;
            this.joindate=joindate;
            this.department=department;
            this.designation_code=designation_code;
            this.basic=basic;
            this.hr=hr;
            this.it=it;

        }

    public String getDepartment() {
        return department;
    }

    public char getDesignation_code() {
        return designation_code;
    }

    public double getBasic() {
        return basic;
    }

    public int getEmpno() {
        return empno;
    }

    public String getEmpname() {
        return empname;
    }

    public double getHr() {
        return hr;
    }

    public double getIt() {
        return it;
    }

    public String getJoindate() {
        return joindate;
    }

}