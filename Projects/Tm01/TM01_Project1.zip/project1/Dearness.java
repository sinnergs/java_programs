public class Dearness {
    public String designation;
    public double da;
    Dearness(String designation,double da){

        this.da=da;
        this.designation=designation;

    }

    public String getDesignation() {
        return designation;
    }

    public double getDa() {
        return da;
    }
}