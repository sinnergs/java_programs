public class Project1{
    public static void main(String[] args){
        Employee[] arr = new Employee[7];
        arr[0]= new Employee("Engineer",20000,1001,"Ashish","01/04/2009","R&D",'e',20000,8000,3000);
        arr[1] = new Employee("Consultant",32000,1002,"Sushma","23/08/2012","PM",'c',30000,12000,9000);
        arr[2] = new Employee("Clerk",12000,1003,"Rahul","12/11/2008","Acct",'k',10000,8000,1000);
        arr[3]  = new Employee("Receptionist",15000,1004,"Chahat","29/01/2013","Front Desk",'r',12000,6000,2000);
        arr[4] = new Employee("Manager",40000,1005,"Ranjan","16/07/2005","Engg",'m',50000,20000,20000);
        arr[5] = new Employee("Engineer",20000,1006,"Suman","1/1/2000","Manufaturing",'e',23000,9000,4400);
        arr[6]  = new Employee("Consultant",32000,1007,"Tanmay","12/06/2006","PM",'c',29000,12000,10000);

        int num = Integer.parseInt(args[0]);
        int sum=0;
        boolean bool = true;
        for(Employee e:arr){
            if(e.empno == num){
                sum+=e.basic+e.hr+e.da-e.it;
                System.out.println(e.empno+" "+e.empname+" "+e.department+" "+e.designation+" "+sum);
                bool=false;
            }

        }
        if(bool==true){
            System.out.println("There is no employee with empid: "+num);
        }
}
    }