package exception;
public class NegativeValueException extends Exception{
    public NegativeValueException(String msg){
        super(msg);
    }

}
