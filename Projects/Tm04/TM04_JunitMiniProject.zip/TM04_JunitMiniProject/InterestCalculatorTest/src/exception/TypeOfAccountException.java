package exception;

public class TypeOfAccountException extends Exception {
    public TypeOfAccountException(String msg){
        super(msg);
    }
}
