import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	   DemoTest.class,
	   Demo2Test.class,
	   EmployeeTest.class
	   
	})


public class Tester{}