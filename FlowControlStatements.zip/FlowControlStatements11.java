public class FlowControlStatements11{
    public static void main(String args[])
    {
        for(int i =23;i<=57;i++){
            if ((i&1)!=1){
                System.out.println(i);
            }
        }
    }
}