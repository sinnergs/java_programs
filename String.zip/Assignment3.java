import java.util.*;
class Assignment3{
    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        String s= sc.nextLine();
        int n = s.length();
        String fs = s.substring(0,2);
        String result="";
        while(n!=0){
            result=result+fs;
            n--;
        }
        System.out.println(result);

   }
}