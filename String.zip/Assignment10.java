import java.util.*;
class Assignment10{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        int n = sc.nextInt();
        String ss = s.substring(s.length()-n,s.length());
        String re="";
        while(n!=0){
            re+=ss;
            n--;
        }
        System.out.println(re);
    }
}