import java.util.*;
class Assignment5{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String ss = s.substring(1,s.length()-1);
        System.out.println(ss);
    }
}