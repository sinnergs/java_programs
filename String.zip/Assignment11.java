public class Assignment11 {
    public static void main(String[] args) {
        String a="XY1XY";
        String b="XY";
        String res="";
        for (int i = 0; i <a.length() ; i++) {
            if(a.charAt(i)=='Y' && i!=0 && a.charAt(i-1)=='X')
            {
                if(isSafe(i-2,a.length())){
                    res+=a.charAt(i-2);
                }
                if(isSafe(i+1,a.length())){
                    res+=a.charAt(i+1);
                }
            }
        }
        System.out.println(res);
    }

    public static boolean isSafe(int x,int length){
        if(x>=0 && x<length){return true;}
        return false;
    }
}



