import java.util.*;
public class Assignment1{
    public static void main(String args[]){
        System.out.println("Enter the string ");
        Scanner scan = new Scanner(System.in);
        String s1 = scan.nextLine();
        String rev="";
        int len = s1.length();
        for(int i = len-1;i>=0;i--){
            rev = rev+s1.charAt(i);
        }

        if (s1.equals(rev)){
            System.out.println("String is Palindrome...");
        }
        else{
            System.out.println("String is not Palindrome....");
        }

    }
}