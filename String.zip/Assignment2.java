import java.util.*;
class Assignment2{
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        String s1 = scan.nextLine();
        String s2 = scan.nextLine();
        String sl = (s1+s2).toLowerCase();
        System.out.println(sl);
    }
}