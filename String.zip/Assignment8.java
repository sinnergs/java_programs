import java.util.*;
class Assignment8{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String ss="";
        if (!s.contains("*")){
            System.out.println("enter the string with * in it");

        }
        else{
            int index = s.indexOf("*");
            if(index!=0 && index !=1 && index !=s.length() && index!=s.length()-1)
            ss+= s.substring(0,index-1)+s.substring(index+2,s.length());

        }
        System.out.println(ss);
    }
}