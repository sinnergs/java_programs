import java.util.*;
import java.lang.*;
class Assignment7{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();

        String ss="";
        if(s.charAt(0)=='x' || s.charAt(s.length()-1)=='x'){
            if(s.charAt(0)=='x' && s.charAt(s.length()-1)=='x')
                ss=ss = s.substring(1,s.length()-1);
            else if(s.charAt(s.length()-1)=='x')
                ss = s.substring(0,s.length()-1);
            else
                ss = s.substring(1,s.length());

        }
        else{
            ss =s;
        }
        System.out.println(ss);
    }
}