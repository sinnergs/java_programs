import java.util.*;
class Assignment9{
    public static String merge(String s1,String s2){
        String result ="";
        for (int i = 0; i < s1.length() ||
                i < s2.length(); i++)
        {


            if (i < s1.length())
                result += s1.charAt(i);


            if (i < s2.length())
                result += s2.charAt(i);
        }
        return result;
    }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();

        int index = s.indexOf(',');
        String s1 = s.substring(0,index);
        String s2 = s.substring(index+1,s.length());
        System.out.println(merge(s1,s2));
    }

}