import java.util.*;
class Assignment6{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        String ss = sc.nextLine();
        String r="";
        if (s.length() == ss.length()){
            System.out.println("Invalid strings");
        }
        else{
            if(s.length()<ss.length()){
                r+=s+ss+s;
            }
            else{
                r+=ss+s+ss;
            }
        }
        System.out.println(r);
    }
}