public class TestEmployee {

    public static void main(String[] args) {
        Employee employee = new Employee("Gurpreet singh", 1000000, 2020, "1623010027abcd");
        System.out.println(employee);
       
    }

}