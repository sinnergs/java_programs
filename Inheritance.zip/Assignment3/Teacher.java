
public class Teacher extends Person {

    int Salary;
    String subject;

    public Teacher(int salary, String subject,String name,String DOB) {
        super(name,DOB);
        Salary = salary;
        this.subject = subject;
    }
}
