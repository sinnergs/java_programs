
public class collegeStudent extends Student {

String collegeName;
String year;

    public collegeStudent(int studentid, String name, String DOB, String collegeName, String year) {
        super(studentid, name, DOB);
        this.collegeName = collegeName;
        this.year = year;
    }
}
