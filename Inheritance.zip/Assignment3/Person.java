

public class Person {
    String name;
    String DOB;

    public Person(String name, String DOB) {
        this.name = name;
        this.DOB = DOB;
    }
}
