
public class Student extends Person{
    int studentid;

    public Student(int studentid,String name,String DOB) {
        super(name, DOB);
        this.studentid = studentid;
    }
}
