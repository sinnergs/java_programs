
public class Assignment3 {
    public static void main(String[] args) {
        String studentname="Tacaz";
        String studentDoB="6August";
        int studentId=11001;
        String cllgName="IIT DELHI";
        String year="Fourth";
        String teacherName="Monu";
        String teacherDOB="21 February";
        int teachersalary=12000;
        String subject="SE";


        collegeStudent obj1=new collegeStudent(studentId,studentname,studentDoB,cllgName,year);
        Teacher obj2=new Teacher(teachersalary,subject,teacherName,teacherDOB);
        System.out.println(obj1.studentid+" "+obj1.name+" "+obj1.DOB+" "+obj1.collegeName+" "+obj1.year);
        System.out.println(obj2.name+" "+obj2.DOB+" "+obj2.subject+" "+obj2.Salary);
    }
}
