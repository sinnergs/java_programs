import java.util.*;
public class Assignment7{
    public void registerUser(String username,String userCountry) throws InvalidCountryException
    {
    if(userCountry.equals("India")){
        System.out.println("User registration done successfully");

    }
    else{
        throw new InvalidCountryException("User Outside India  cannot be registered");
    }

    }




    public static void main(String args[]){
    Assignment7 a = new Assignment7();
    Scanner sc = new Scanner(System.in);
    String s1=sc.nextLine();
    String s2=sc.nextLine();
    try{
    a.registerUser(s1,s2);
    }
    catch(Exception e){
    System.out.println(e);}
    }
}