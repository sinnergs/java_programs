import java.util.*;
public class Assignment5{


    public static double division(int a , int b) throws ArithmeticException {
        return a/b;
    }

    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        int a= scan.nextInt();
        int b= scan.nextInt();

        try {
            double r = division(a, b);
            System.out.println(r);
        } catch (ArithmeticException e) {
            System.out.println(e);
        }
    }
}