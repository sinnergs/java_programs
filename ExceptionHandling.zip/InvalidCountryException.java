public class InvalidCountryException extends Exception{

   public InvalidCountryException(String n)
    {    super();
        System.out.println(n);
    }
}