import java.io.*;
import java.util.*;

public class Assignment2{
    public static void main(String args[]){
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array");
        int n = scan.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i]=scan.nextInt();
        }
        try{
            System.out.println("Enter the index of the array element you want to access");
            System.out.println(arr[scan.nextInt()]);
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e);

        }
    }
}