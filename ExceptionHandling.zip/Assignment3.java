import java.util.*;
import java.io.*;

public class Assignment3{
    public static void main(String args[])
    {
        try{
            Scanner scan = new Scanner(System.in);
            System.out.println("Enter the number of elements in the array");
            int n = scan.nextInt();
            int[] arr = new int[n];
            for(int i=0;i<n;i++){
                arr[i]=scan.nextInt();
            }
            System.out.println("Enter the index of the array element you want to access");
            System.out.println(arr[scan.nextInt()]);
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println(e);

        }
        catch (InputMismatchException e){
            System.out.println(e);

        }

    }
}