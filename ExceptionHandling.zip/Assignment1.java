import java.io.*;
import java.lang.*;
import java.util.*;
public class Assignment1{
    public static void main(String args[]){
        System.out.println("Enter an Integer");
        Scanner scan = new Scanner(System.in);
        String s = scan.nextLine();

        try{
             int a = Integer.parseInt(s);
             System.out.println(Math.pow(a,2));
        }
        catch (NumberFormatException e){
            System.out.println("Entered input is not a valid format for an integer.");
        }
    }
}