import java.util.*;

public class Assignment6 {

    public static void main(String[] args) {


        for (int i = 0; i < 2; i++) {
            String name = "";
            int subA = 0;
            int subB = 0;
            int subC = 0;
            Scanner sc = new Scanner(System.in);
            try {
                System.out.println("Enter Name:");
                name = sc.nextLine();

                try{
                    System.out.println("Enter sub:");

                    subA=Integer.parseInt(sc.next());
                    System.out.println("Enter sub:");
                    subB=Integer.parseInt(sc.next());
                    System.out.println("Enter sub:");
                    subC=Integer.parseInt(sc.next());
                }
                catch(NumberFormatException e)
                {System.out.println(e);}

                if (subA < 0) throw new NegativeValuesException();
                if (subA > 100) throw new ValuesOutOfRangeException();

                if (subB < 0) throw new NegativeValuesException();
                if (subB > 100) throw new ValuesOutOfRangeException();

                if (subC < 0) throw new NegativeValuesException();
                if (subC > 100) throw new ValuesOutOfRangeException();


            } catch (ArithmeticException e) {
                System.out.println(e);
            } catch (NegativeValuesException e) {
                System.out.println(e);
            } catch (ValuesOutOfRangeException e) {
                System.out.println(e);
            }



            System.out.println("Name: " + name);
            System.out.println("Marks of subject A: " + subA);
            System.out.println("Marks of subject B: " + subB);
            System.out.println("Marks of subject C: " + subC);

        }



    }

}