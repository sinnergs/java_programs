class ValuesOutOfRangeException extends Exception {
    public ValuesOutOfRangeException() {
        super();
        System.out.println("ValuesOutOfRangeException occured");
    }
}
