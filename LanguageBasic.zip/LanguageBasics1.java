class LanguageBasics1{
    public static void main(String args[]){
        String first = args[0]+" Technologies ";
        String sec = args[1];
        System.out.println(first+sec);
    }
}