package ju;

public class Demo1 {
	public String StringConcat(String s1,String s2) {
		return s1+s2;
	}
}
