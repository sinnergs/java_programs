package ju;

import static org.junit.Assert.*;

import org.junit.Test;

public class DemoTest {

	@Test
	public void StringConcat() {
		Demo1 d= new Demo1();
		assertEquals("hw",d.StringConcat("h", "w"));
		assertEquals("hello",d.StringConcat("hel", "lo"));
	}
	
}
