import java.util.*;
import java.io.*;
public class Assignment1{
    public static void main(String args[]) throws IOException {
        System.out.println("Enter the file name");
        Scanner sc = new Scanner(System.in);
        String fileName = sc.nextLine();
        System.out.println("enter the character to be counted");
        char ch = sc.next().charAt(0);
        try{
            int c,count=0;
            File input = new File(fileName);
            FileReader in = new FileReader(input);
            while((c=in.read())!=-1){
                char d = (char) c;
                if(d==ch){
                    count++;
                }
            }
            System.out.println("File "+fileName+" has "+count+" instances of letter "+ch);
        }
        catch(Exception e){
            System.out.println(e);
        }



    }
}