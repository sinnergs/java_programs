import java.util.*;
import java.io.*;
public class Assignment2{
    public static void main(String args[]) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the input file name");
        String si = sc.nextLine();
        System.out.println("Enter the output file name ");
        String so = sc.nextLine();
        FileInputStream fin;
        FileOutputStream fout;
        try{
            fin = new FileInputStream(si);
        }
        catch(FileNotFoundException e){
            System.out.println("FIle not found ");
            return;
        }
        try{
            fout = new FileOutputStream(so);
        }
        catch(IOException e){
            System.out.println("Error opening the file ");
            return;
        }
        try{
            int len;
            do{
                len = fin.read();
                if(len!=-1)
                    fout.write(len);
            }while(len!=-1);
        }
        catch(IOException e){
            System.out.println("Error opening the file ");
        }
        fin.close();
        fout.close();
        System.out.println("File Copied");
    }
}