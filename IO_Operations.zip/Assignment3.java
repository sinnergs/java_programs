import java.util.*;
import java.io.*;

public class Assignment3{
    public static void main(String args[]) throws  IOException{
        Map<String, Integer> mapLang = new TreeMap<>();
        Scanner fin;
        FileWriter fout;
        String inputFile = args[0];
        String outputFile = args[1];
        try{
            fin = new Scanner(new FileInputStream(inputFile));
        }
        catch(FileNotFoundException e){
            System.out.println("FIle not found ");
            return;
        }
        try{
            fout = new FileWriter(outputFile);
        }
        catch(IOException e){
            System.out.println("Error opening the file ");
            return;
        }

            ArrayList<String> list = new ArrayList<>();

            while (fin.hasNext()) {
                list.add(fin.next());
            }


            for (String w : list){
                Integer i = mapLang.get(w);
                if(i == null){
                    mapLang.put(w, 1);
                }
                else {
                    mapLang.put(w, i+1);
                }
            }
            try {
                String build = "";
                for(String str : mapLang.keySet()){
                    if(build!="")build+="\n";
                    build+=mapLang.get(str)+" "+str;

                }
                fout.write(build);

            }
        catch(Exception e){
            System.out.println("invalid");
        }
            finally {
                fout.close();
            }

        System.out.println("done.....");
        }

    }
