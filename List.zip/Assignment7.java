import java.util.*;
public class Assignment7 {

        public static void main (String[]args){

            Vector<Employee> v = new Vector<Employee>();
            Employee e1 = new Employee(110, "gurpreet", "vishu@gmail.com", "M", 3000000);
            Employee e2 = new Employee(112, "gur", "ishu@gmail.com", "M", 10000);
            Employee e3 = new Employee(113, "reet", "shu@gmail.com", "F", 400000);
            v.add(e1);
            v.add(e2);
            v.add(e3);
            System.out.println("USing iterator");
            Iterator i = v.iterator();
            while (i.hasNext()) {
               System.out.println(i.next());
            }
            System.out.println("USing Enumeration");
            Enumeration e = v.elements();
            while(e.hasMoreElements())
            {
                System.out.println(e.nextElement());
            }



        }

}