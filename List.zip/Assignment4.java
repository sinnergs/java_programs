import java.util.*;
public class Assignment4{
    public static void main(String[] args){
        List<Number> ls = new ArrayList<Number>();
        ls.add(1);
        ls.add(2.0);
    }
}