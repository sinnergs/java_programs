import java.util.*;
public class Assignment3{
    public static void main(String[] args){
        List<String> ls = new ArrayList<String>();
        ls.add("hello");
        ls.add("world");
        Iterator i = ls.iterator();
        while(i.hasNext()){
            System.out.println(i.next());
        }
    }
}