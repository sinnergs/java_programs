import java.util.*;
public class Assignment1{
    public static void main(String args[]){
        List<String> month = new ArrayList<String>();
        month.add("Jan");
        month.add("Feb");
        month.add("Mar");
        month.add("April");
        month.add("May");
        month.add("June");
        month.add("July");
        month.add("Aug");
        month.add("Sept");
        month.add("Oct");
        month.add("Nov");
        month.add("Dec");
        for(Object o : month){
            System.out.println(o);
        }

    }
}