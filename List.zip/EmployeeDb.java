import java.util.*;
public class EmployeeDb{
    static List<Employee> ls = new ArrayList<Employee>();
    public static boolean addEmployee(Employee e ){
        ls.add(e);
        System.out.println("added");
        return true;
    }
    public static boolean deleteEmployee(int empId){
        for(Employee em:ls){
            if (em.empId == empId){
                ls.remove(em);

            }

        }
    return true;
    }
    public static String showPaySlip(int empId){
        for(Employee em:ls){
            if (em.empId == empId) {
                return "salary: " + em.salary;
            }
        }
        return("empid: "+empId+"doesnot exist");
    }



    public static void main(String[] args){
        Employee e1= new Employee(110,"gurpreet","vishu@gmail.com","M",3000000);
        Employee e2= new Employee(112,"gur","ishu@gmail.com","M",10000);
        Employee e3= new Employee(113,"reet","shu@gmail.com","F",400000);
        addEmployee(e1);
        addEmployee(e2);
        addEmployee(e3);
        for(Employee e : ls){
            System.out.println(e.empId);
        }
        System.out.println(showPaySlip(110));
        deleteEmployee(112);
        for(Employee e : ls){
            System.out.println(e.empId);
        }

    }
}