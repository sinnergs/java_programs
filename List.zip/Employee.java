public class Employee {
    public int empId;
    public String empName, email, gender;
    public double salary;

    Employee(int empId, String empName, String email, String gender, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.email = email;
        this.gender = gender;
        this.salary = salary;
    }

    void GetEmployeeDetails() {
        System.out.println("empId: " + this.empId + " empName: " + this.empName + " email: " + this.email + " gender: " + this.gender + " salary: " + this.salary);
    }
}